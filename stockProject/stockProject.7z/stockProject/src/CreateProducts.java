import java.util.ArrayList;
public class CreateProducts {
    private static int productCode = 1;
    private static ArrayList<Product> products = new ArrayList<Product>();
    public static void addProduct(Product p){
        products.add(p);
        productCode += 1;
    }

    public static ArrayList<Product> getProducts(){
        return products;
    }

    public static int getProductCode(){
        return productCode;
    }


}
