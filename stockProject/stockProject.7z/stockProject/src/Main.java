import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        int codeEntered;
        boolean found = false;

        CreateProducts.addProduct( new Product( "box", "manufacturing", "small box", 10, 3));
        CreateProducts.addProduct( new Product("container","power tools",  "blue box", 5,6));
        CreateProducts.addProduct(new Product( "bottle","Kitchen", "bottle of water", 20, 2));
        CreateProducts.addProduct(new Product( "pencil","RH", "blue pencil", 50, 0.5F));

        System.out.println("Product code: ");
        codeEntered = scan.nextInt();

        for(Product p : CreateProducts.getProducts()){
            if(codeEntered == p.getCode()){
                p.showProductInfos();
                found = true;
                break;
            }else{
                found = false;
            }
        }
        if(!found){
            System.out.println("Product not found");
        }
    }
}

