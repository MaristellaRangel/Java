public class Product {
    private int code, quantity;
    private float unityPrice, totalPrice;
    private String name, area, details;
    private boolean status;

    Product( String name, String area, String details, int quantity, float unityPrice){
        this.code = CreateProducts.getProductCode();
        this.name = name;
        this.area = area;
        this.details = details;
        this.quantity = quantity;
        this.unityPrice = unityPrice;
        this.totalPrice = (unityPrice * quantity);
        this.status = true;
    }

    public int getCode(){
      return this.code;
    }

    public String getName(){
        return this.name;
    }

    public String getArea(){
        return this.area;
    }

    public String getDetails(){
        return this.details;
    }

    public int getQuantity(){
        return this.quantity;
    }
    public float getUnityPrice(){
        return this.unityPrice;
    }

    public float getTotalPrice(){
        return this.totalPrice;
    }

    public boolean getStatus(){
        return this.status;
    }

    public void setStatus(boolean s){
        this.status = s;
    }

    public void showProductInfos(){
        System.out.println("Name: " + this.getName());
        System.out.println("Quantity: " + this.getQuantity());
        System.out.println("Unity Price: " + this.getUnityPrice());
        System.out.println("Total price: " + this.getTotalPrice());
        System.out.println("Area: " + this.getArea());
        System.out.println("Product Details: " + this.getDetails());
        if(this.getStatus()){
            System.out.println("Sent to " + this.getArea());
        }else{
            System.out.println("Product not sent to " + this.getArea());
        }
    }
}
